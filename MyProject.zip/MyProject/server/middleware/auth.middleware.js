import jwt from "jsonwebtoken";

import User from "../models/user.model.js";


const protect = async (req, res, next) => {

    try {

        const authorization =
            req.headers.authorization;


        if (
            !authorization ||
            !authorization.startsWith("Bearer ")
        ) {

            return res.status(401).json({
                message:
                    "Authentication required."
            });

        }


        const token =
            authorization.split(" ")[1];


        const decoded =
            jwt.verify(
                token,
                process.env.JWT_SECRET
            );


        const user =
            await User.findById(
                decoded.userId
            );


        if (!user) {

            return res.status(401).json({
                message:
                    "Authenticated user no longer exists."
            });

        }


        req.user =
            user;


        next();

    }

    catch (error) {

        return res.status(401).json({
            message:
                "Invalid or expired authentication token."
        });

    }

};


export default protect;